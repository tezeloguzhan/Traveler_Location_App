package com.tezeloguzhan.travelerlocation;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;



public class MainActivity extends AppCompatActivity implements LocationListener {
    private Button btnKamera, btnKonum,btnPaylas;
    private TextView textView;
    private String konumSaglayici = "gps";
    private LocationManager locationManager;
    private ImageView resim;
    Bitmap image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnKamera = findViewById(R.id.btnKamera);
        btnPaylas = findViewById(R.id.btnPaylas);
        btnKonum = findViewById(R.id.btnKonum);
        textView = findViewById(R.id.textView);
        resim =  findViewById(R.id.imageView);


        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        btnKamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ){
                    Toast.makeText(MainActivity.this, "PLEASE ALLOW CAMERA!!!", Toast.LENGTH_SHORT).show();
                }else{
                    Intent kamera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(kamera, 1);
                }


            }
        });


        btnKonum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    textView.setText("PLEASE ALLOW LOCATİON!!!");
                    return;
                }else{
                    Location konum = locationManager.getLastKnownLocation(konumSaglayici);
                    if (konum != null){
                        onLocationChanged(konum);
                    }else{
                        textView.setText("COULDN'T GET LOCATİON!!!");
                    }
                }

                // onLocationChanged();
            }
        });


        btnPaylas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PackageManager pm=getPackageManager();

                try {
                    Intent waIntent = new Intent(Intent.ACTION_SEND);

                    waIntent.setType("text/plain");
                    String text = textView.getText().toString();

                    PackageInfo info=pm.getPackageInfo("com.whatsapp", PackageManager.GET_META_DATA);

                    waIntent.setPackage("com.whatsapp");
                    waIntent.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(waIntent, "Paylaş"));

                }catch (Exception e){
                    Toast.makeText(MainActivity.this, "Whatsapp Yüklü Değil!!!", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == 1){

            image = (Bitmap) data.getExtras().get("data");

            resim.setImageBitmap(image);
            resim.setDrawingCacheEnabled(true);

            Bitmap b = resim.getDrawingCache();

            MediaStore.Images.Media.insertImage(getApplicationContext().getContentResolver(), b,"title", "description");
        }

        super.onActivityResult(requestCode,resultCode,data);

    }

    @Override
    public void onLocationChanged(Location location) {

        double enlem = location.getLatitude();
        double boylam = location.getLongitude();
        textView.setText("LATITUDE : "+enlem+"\nLONGITUDE : "+boylam);

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }


}